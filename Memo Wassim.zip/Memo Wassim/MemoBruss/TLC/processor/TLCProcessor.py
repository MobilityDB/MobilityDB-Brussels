import json
from datetime import datetime, timedelta
import requests  # Import the requests library for making HTTP requests

def process_api_response(api_url):
    # Make a GET request to the API
    response = requests.get(api_url)

    if response.status_code != 200:
        print(f"Error: {response.status_code}")
        return None

    json_data = response.json()
    result = generate_results(json_data)
    return result

def generate_results(json_data):
    if not json_data:
        print("Error: Empty JSON data")
        return None

    for entry in json_data.get('results', []):
        timeline_timestamp = entry['data']['rawData']['timeline']['Timestamp']
        data_points = entry['data']['rawData']['data']
        identifier = entry['data']['rawData']['Id']

        result = []

        for data_point in data_points:
            value = data_point['Value']
            offset = data_point['EventsOffsets'][0]['offset'] / 1000  # Convert milliseconds to seconds
            timestamp = datetime.strptime(timeline_timestamp, "%Y-%m-%dT%H:%M:%S.%f%z") + timedelta(seconds=offset)
            result.append(f"{value}@{timestamp.strftime('%Y-%m-%dT%H:%M:%S.%f%z')}")

        # Sort the result by the timestamp
        result.sort(key=lambda x: x.split('@')[1])

        print("Id:", identifier, "values:", result)

# Replace 'your_api_url' with the actual API URL
api_url = 'http://10.105.128.243:3000/api/rawData/signalgroups/SAB03?begin=1690848000'
process_api_response(api_url)
